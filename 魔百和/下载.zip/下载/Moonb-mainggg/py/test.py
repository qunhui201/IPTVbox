#!/usr/bin/env python3
import requests
from bs4 import BeautifulSoup
import json
import time
import random
import os
import logging
from pathlib import Path
import sys

# 设置日志，输出到文件和控制台
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('scraper.log', mode='w', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)

# 代理域名
base_url = "https://29f9.yubb.cloudns.be"
excluded_url = f"{base_url}/view/?id=cnhn7hdk"  # 要屏蔽的重复子网页

# 请求头伪装
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Connection": "keep-alive",
    "Referer": base_url
}

def fetch_page_urls(page_num):
    """获取分页中的子网页 URL 和图片链接，确保唯一且排除重复"""
    page_url = f"{base_url}/?type=gc&p={page_num}"
    try:
        response = requests.get(page_url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        links = soup.select('a[href*="/view/?id="][data-original]')
        logging.info(f"页面 {page_num} 找到 {len(links)} 个子网页链接")

        url_image_pairs = []
        seen_urls = set()
        for link in links:
            href = link['href'] if link['href'].startswith('http') else base_url + link['href']
            if excluded_url in href or href in seen_urls:
                continue
            seen_urls.add(href)

            image_url = link.get('data-original', "未找到图片链接")
            url_image_pairs.append({
                "url": href,
                "image_url": image_url
            })

        url_list = url_image_pairs[:40]
        logging.info(f"页面 p={page_num} 筛选后得到 {len(url_list)} 个唯一子网页链接")
        return url_list
    except requests.exceptions.RequestException as e:
        logging.error(f"获取分页 {page_url} 失败: {e}")
        return []
    except Exception as e:
        logging.error(f"处理分页 {page_url} 时发生未知错误: {e}")
        return []

def fetch_subpage_content(subpage_url, max_retries=3, retry_delay=5):
    """抓取子网页的 m3u8 链接和标题"""
    for attempt in range(max_retries):
        try:
            response = requests.get(subpage_url, headers=headers, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')

            # 尝试从 <img#video_img> 或 <source#mp4m3u8> 获取 m3u8 链接
            m3u8 = None
            img_tag = soup.select_one('img#video_img')
            if img_tag and 'm3u8' in img_tag.get('src', '').lower():
                m3u8 = img_tag['src']
                logging.info(f"从 <img#video_img> 获取 m3u8: {m3u8}")
            else:
                source = soup.select_one('source#mp4m3u8')
                m3u8 = source['src'] if source and source.get('src') else "未找到 m3u8 链接"
                if m3u8 != "未找到 m3u8 链接":
                    logging.info(f"从 <source#mp4m3u8> 获取 m3u8: {m3u8}")

            # 验证 m3u8 链接
            if m3u8 and m3u8 != "未找到 m3u8 链接":
                try:
                    response = requests.get(m3u8, headers=headers, timeout=5)
                    if response.status_code != 200:
                        m3u8 = f"无效的 m3u8 链接 (状态码: {response.status_code})"
                except requests.exceptions.RequestException as e:
                    m3u8 = f"无法访问的 m3u8 链接: {e}"

            # 提取标题
            title_elem = soup.find('title')
            title = title_elem.text.strip().replace(" - 黄色仓库 - hsck123.com", "") if title_elem else "未找到标题"

            return {
                "url": subpage_url,
                "m3u8": m3u8,
                "title": title
            }
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 429:
                logging.warning(f"请求 {subpage_url} 被限流，等待 {retry_delay * 2}s")
                time.sleep(retry_delay * 2)
            elif attempt < max_retries - 1:
                logging.warning(f"请求 {subpage_url} HTTP 错误: {e}，{retry_delay}s 后重试")
                time.sleep(retry_delay)
            else:
                logging.error(f"请求 {subpage_url} 失败 {max_retries} 次: {e}")
                return {"url": subpage_url, "error": str(e)}
        except requests.exceptions.Timeout as e:
            if attempt < max_retries - 1:
                logging.warning(f"请求 {subpage_url} 超时，{retry_delay}s 后重试")
                time.sleep(retry_delay)
            else:
                logging.error(f"请求 {subpage_url} 超时 {max_retries} 次")
                return {"url": subpage_url, "error": str(e)}
        except Exception as e:
            logging.error(f"请求 {subpage_url} 发生未知错误: {e}")
            return {"url": subpage_url, "error": str(e)}

def save_to_json(data, page_num, output_dir):
    """将数据保存为页面级 JSON 文件"""
    filename = output_dir / f"hsck4_page_{page_num}.json"
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        logging.info(f"保存页面 JSON: {filename}")
        return filename
    except Exception as e:
        logging.error(f"保存 JSON {filename} 失败: {e}")
        return None

def save_aggregated_json(all_results, output_dir):
    """将有效数据保存为 n002.json"""
    aggregated_data = {"zhubo": []}
    for item in all_results:
        if "error" not in item and "未找到 m3u8 链接" not in item["m3u8"] and "无效" not in item["m3u8"]:
            aggregated_data["zhubo"].append({
                "address": item["m3u8"],
                "img": item["image_url"],
                "title": item["title"]
            })

    filename = output_dir / "n800.json"
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(aggregated_data, f, ensure_ascii=False, indent=2)
        logging.info(f"保存聚合 JSON: {filename}")
    except Exception as e:
        logging.error(f"保存聚合 JSON {filename} 失败: {e}")

def main():
    """主函数，抓取页面并生成 JSON 文件"""
    # 设置输出目录为仓库中的 test 文件夹
    output_dir = Path(__file__).parent.parent / "test"
    
    # 创建输出目录
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
        logging.info(f"输出目录: {output_dir}")
    except Exception as e:
        logging.error(f"无法创建目录 {output_dir}: {e}")
        return

    all_results = []
    for page_num in range(701, 790):  # 限制为 2 页用于测试
        logging.info(f"抓取页面 p={page_num}")
        subpage_data = fetch_page_urls(page_num)
        if not subpage_data:
            logging.warning(f"页面 p={page_num} 无数据，跳过")
            continue

        page_results = []
        for i, item in enumerate(subpage_data, 1):
            logging.info(f"处理子网页 {i}/{len(subpage_data)}: {item['url']}")
            content = fetch_subpage_content(item["url"])
            content["image_url"] = item["image_url"]
            page_results.append(content)
            all_results.append(content)
            time.sleep(random.uniform(0.5, 1.5))

        # 保存页面级 JSON
        save_to_json(page_results, page_num, output_dir)

    # 保存聚合 JSON
    save_aggregated_json(all_results, output_dir)

if __name__ == "__main__":
    try:
        logging.info("启动抓取脚本...")
        main()
        logging.info("抓取完成，JSON 文件已生成！")
    except Exception as e:
        logging.error(f"脚本运行失败: {e}")
