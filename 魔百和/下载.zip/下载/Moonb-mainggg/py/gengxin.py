#!/usr/bin/env python3
import requests
from bs4 import BeautifulSoup
import json
import time
import random
import logging
from pathlib import Path
import sys

# 日志配置
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('scraper_incremental.log', mode='w', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)

# 代理域名
base_url = "https://29f9.yubb.cloudns.be"
stop_url = f"{base_url}/view/?id=3uasbi5z"  # 终止抓取的网页

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Connection": "keep-alive",
    "Referer": base_url
}

def fetch_page_urls(page_num):
    """获取分页子网页 URL 和图片"""
    page_url = f"{base_url}/?type=gc&p={page_num}"
    try:
        r = requests.get(page_url, headers=headers, timeout=10)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, 'html.parser')
        links = soup.select('a[href*="/view/?id="][data-original]')

        url_list = []
        seen_urls = set()
        for link in links:
            href = link['href']
            if not href.startswith('http'):
                href = base_url + href
            if href in seen_urls:
                continue
            seen_urls.add(href)
            url_list.append({
                "url": href,
                "image_url": link.get("data-original", "")
            })
        return url_list[:40]
    except Exception as e:
        logging.error(f"抓取页面 {page_num} 失败: {e}")
        return []

def fetch_subpage_content(subpage_url):
    """抓取子网页的 m3u8 和标题"""
    try:
        r = requests.get(subpage_url, headers=headers, timeout=10)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, 'html.parser')

        m3u8 = None
        img_tag = soup.select_one('img#video_img')
        if img_tag and 'm3u8' in img_tag.get('src', '').lower():
            m3u8 = img_tag['src']
        else:
            source = soup.select_one('source#mp4m3u8')
            if source and source.get('src'):
                m3u8 = source['src']
        if not m3u8:
            m3u8 = "未找到 m3u8 链接"

        title_elem = soup.find('title')
        title = title_elem.text.strip().replace(" - 黄色仓库 - hsck123.com", "") if title_elem else "未找到标题"
        return {"url": subpage_url, "m3u8": m3u8, "title": title}
    except Exception as e:
        logging.error(f"抓取 {subpage_url} 失败: {e}")
        return {"url": subpage_url, "error": str(e)}

def save_page_json(data, page_num, output_dir):
    filename = output_dir / f"hsck4_page_{page_num}.json"
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        logging.info(f"保存页面 JSON: {filename}")
    except Exception as e:
        logging.error(f"保存 {filename} 失败: {e}")

def save_aggregated_json(all_results, output_dir):
    aggregated = {"zhubo": []}
    for item in all_results:
        if "error" not in item and "未找到 m3u8 链接" not in item["m3u8"]:
            aggregated["zhubo"].append({
                "address": item["m3u8"],
                "img": item["image_url"],
                "title": item["title"]
            })
    filename = output_dir / "n001.json"
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(aggregated, f, ensure_ascii=False, indent=2)
        logging.info(f"保存聚合 JSON: {filename}")
    except Exception as e:
        logging.error(f"保存聚合 JSON 失败: {e}")

def main():
    output_dir = Path(__file__).parent.parent / "test/gengxin"
    output_dir.mkdir(parents=True, exist_ok=True)
    logging.info(f"输出目录: {output_dir}")

    all_results = []
    stop_reached = False
    page_num = 1

    while not stop_reached:
        logging.info(f"抓取第 {page_num} 页")
        urls = fetch_page_urls(page_num)
        if not urls:
            logging.warning(f"第 {page_num} 页无数据，停止抓取")
            break

        page_results = []
        for idx, item in enumerate(urls, 1):
            logging.info(f"处理子网页 {idx}/{len(urls)}: {item['url']}")
            content = fetch_subpage_content(item["url"])
            content["image_url"] = item["image_url"]
            page_results.append(content)
            all_results.append(content)
            time.sleep(random.uniform(0.5, 1.5))

            if item["url"] == stop_url:
                logging.info(f"检测到终止网页 {stop_url}，停止抓取。")
                stop_reached = True
                break

        save_page_json(page_results, page_num, output_dir)
        if stop_reached:
            break
        page_num += 1

    save_aggregated_json(all_results, output_dir)
    logging.info("抓取完成！")

if __name__ == "__main__":
    main()
